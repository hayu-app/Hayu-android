#!/data/data/com.termux/files/usr/bin/bash
# HAYU - Patch 7: SVGA MANAGER (developer upload SVGA untuk frame, car, gift, dll)
#  - Dev Panel: tile "SVGA Manager" (khusus developer), upload .svga ke Firebase Storage
#  - Gift SVGA di panel hadiah & diputar untuk semua orang di room
#  - Frame & Car dijual di Toko; frame di avatar profil, car diputar saat masuk room
#   cd ~/Hayu-android && bash patch-svga.sh
set -e
REPO="${REPO:-$PWD}"
cd "$REPO"
D="app/src/main/java/com/hayu/app"
[ -d "$D" ] || { echo "❌ Jalankan di root repo Hayu-android"; exit 1; }
[ -f "app/src/main/java/com/hayu/app/SvgaCatalog.kt" ] && { echo "✅ Patch ini sudah terpasang, tidak ada yang diubah."; exit 0; }
command -v git >/dev/null 2>&1 || pkg install -y git
command -v patch >/dev/null 2>&1 || pkg install -y patch

P="$(mktemp)"
cat > "$P" <<'PATCH_EOF'
diff --git a/app/build.gradle.kts b/app/build.gradle.kts
index 3349200..ec78627 100644
--- a/app/build.gradle.kts
+++ b/app/build.gradle.kts
@@ -68,4 +68,7 @@ dependencies {
 
     // OkHttp (untuk upload gambar ke imgbb)
     implementation("com.squareup.okhttp3:okhttp:4.12.0")
+
+    // SVGA player (animasi frame, car, gift) - dari JitPack
+    implementation("com.github.yyued:SVGAPlayer-Android:2.6.1")
 }
diff --git a/app/src/main/AndroidManifest.xml b/app/src/main/AndroidManifest.xml
index 9fb347b..153d14a 100644
--- a/app/src/main/AndroidManifest.xml
+++ b/app/src/main/AndroidManifest.xml
@@ -63,6 +63,11 @@
             android:exported="false"
             android:screenOrientation="portrait" />
 
+        <activity
+            android:name=".SvgaManagerActivity"
+            android:exported="false"
+            android:screenOrientation="portrait" />
+
         <activity
             android:name=".OrgActivity"
             android:exported="false"
diff --git a/app/src/main/java/com/hayu/app/DevPanelActivity.kt b/app/src/main/java/com/hayu/app/DevPanelActivity.kt
index 7206d6d..cc48fd0 100644
--- a/app/src/main/java/com/hayu/app/DevPanelActivity.kt
+++ b/app/src/main/java/com/hayu/app/DevPanelActivity.kt
@@ -38,6 +38,7 @@ class DevPanelActivity : AppCompatActivity() {
         PanelItem("🔔", "Notifikasi",          "notif"),
         PanelItem("📈", "Reports",             "report"),
         PanelItem("⚙️", "System & Dev Tools", "system"),
+        PanelItem("🎞️", "SVGA Manager",       "svga"),
     )
 
     override fun onCreate(savedInstanceState: Bundle?) {
@@ -172,6 +173,10 @@ class DevPanelActivity : AppCompatActivity() {
     }
 
     private fun openPanel(key: String, label: String) {
+        if (key == "svga") {
+            startActivity(Intent(this, SvgaManagerActivity::class.java))
+            return
+        }
         val intent = Intent(this, PanelDetailActivity::class.java)
         intent.putExtra("panel_key", key)
         intent.putExtra("panel_label", label)
diff --git a/app/src/main/java/com/hayu/app/GiftSheet.kt b/app/src/main/java/com/hayu/app/GiftSheet.kt
index 51774f5..ee70a19 100644
--- a/app/src/main/java/com/hayu/app/GiftSheet.kt
+++ b/app/src/main/java/com/hayu/app/GiftSheet.kt
@@ -15,9 +15,9 @@ import com.google.firebase.firestore.FirebaseFirestore
 
 object GiftSheet {
 
-    private class Gift(val emoji: String, val name: String, val price: Int)
+    private class Gift(val emoji: String, val name: String, val price: Int, val svgaUrl: String? = null)
 
-    private val gifts = listOf(
+    private val baseGifts = listOf(
         Gift("🌹", "Mawar", 10),
         Gift("☕", "Kopi", 20),
         Gift("🍫", "Cokelat", 30),
@@ -28,13 +28,31 @@ object GiftSheet {
         Gift("💎", "Berlian", 1000)
     )
 
+    // baseGifts + gift SVGA unggahan Developer (diisi ulang tiap sheet dibuka)
+    private var gifts: List<Gift> = baseGifts
+
     // recipients: pasangan (uid, nama tampil). Boleh berisi uid sendiri.
     // onSent(teks pesan, emoji hadiah)
+    // onSent(teks pesan, emoji hadiah, url SVGA atau null)
     fun show(
         activity: AppCompatActivity,
         myNickname: String,
         recipients: List<Pair<String, String>>,
-        onSent: (String, String) -> Unit
+        onSent: (String, String, String?) -> Unit
+    ) {
+        SvgaCatalog.load(SvgaCatalog.GIFT) { assets ->
+            gifts = baseGifts + assets.map {
+                Gift(it.emoji.ifBlank { "🎁" }, it.name, it.price, it.url)
+            }
+            showInternal(activity, myNickname, recipients, onSent)
+        }
+    }
+
+    private fun showInternal(
+        activity: AppCompatActivity,
+        myNickname: String,
+        recipients: List<Pair<String, String>>,
+        onSent: (String, String, String?) -> Unit
     ) {
         val db = FirebaseFirestore.getInstance()
         val myUid = FirebaseAuth.getInstance().currentUser?.uid ?: return
@@ -166,7 +184,7 @@ object GiftSheet {
                 send(activity, db, myUid, myNickname, to, g, qty,
                     onDone = { text ->
                         dialog.dismiss()
-                        onSent(text, g.emoji)
+                        onSent(text, if (g.svgaUrl != null) "" else g.emoji, g.svgaUrl)
                     },
                     onFail = { sendBtn.isEnabled = true }
                 )
@@ -239,7 +257,9 @@ object GiftSheet {
             }
             null
         }.addOnSuccessListener {
-            GiftAnimation.show(activity, g.emoji, g.name)
+            val svga = g.svgaUrl
+            if (svga != null) SvgaOverlay.show(activity, svga)
+            else GiftAnimation.show(activity, g.emoji, g.name)
 
             val text = if (isSelf) {
                 "$myName mengirim ${g.emoji} ${g.name} x$qty untuk dirinya sendiri"
diff --git a/app/src/main/java/com/hayu/app/ProfileFragment.kt b/app/src/main/java/com/hayu/app/ProfileFragment.kt
index f125803..493a3b3 100644
--- a/app/src/main/java/com/hayu/app/ProfileFragment.kt
+++ b/app/src/main/java/com/hayu/app/ProfileFragment.kt
@@ -140,6 +140,7 @@ class ProfileFragment : Fragment() {
                 val nickname = doc.getString("nickname") ?: "Pengguna HAYU"
                 val gelar = doc.getString("equippedTitle") ?: ""
                 tvNickname.text = if (gelar.isNotBlank()) "$gelar $nickname" else nickname
+                SvgaFrame.attach(imgAvatar, doc.getString("equippedFrameUrl"))
 
                 val age = (doc.getLong("age") ?: 0L).toInt()
                 val gender = doc.getString("gender") ?: ""
diff --git a/app/src/main/java/com/hayu/app/RoomActivity.kt b/app/src/main/java/com/hayu/app/RoomActivity.kt
index 591b800..d5d6148 100644
--- a/app/src/main/java/com/hayu/app/RoomActivity.kt
+++ b/app/src/main/java/com/hayu/app/RoomActivity.kt
@@ -20,8 +20,11 @@ import androidx.recyclerview.widget.LinearLayoutManager
 import androidx.recyclerview.widget.RecyclerView
 import com.google.android.material.bottomsheet.BottomSheetDialog
 import com.google.firebase.auth.FirebaseAuth
+import com.google.firebase.firestore.DocumentChange
+import com.google.firebase.firestore.DocumentSnapshot
 import com.google.firebase.firestore.FirebaseFirestore
 import com.google.firebase.firestore.ListenerRegistration
+import com.google.firebase.firestore.QuerySnapshot
 import com.hayu.app.adapter.RoomMessageAdapter
 import com.hayu.app.model.RoomMessage
 import com.hayu.app.util.SessionManager
@@ -132,6 +135,7 @@ class RoomActivity : AppCompatActivity() {
                         myNickname = userDoc.getString("nickname") ?: "Pengguna HAYU"
                         setupMicSlots()
                         listenMicSlots()
+                        announceCarEntrance(userDoc)
                     }
             }
             .addOnFailureListener {
@@ -422,9 +426,9 @@ class RoomActivity : AppCompatActivity() {
             }
         }
         list.add(Pair(me, "Saya"))
-        GiftSheet.show(this, myNickname, list) { text, emoji ->
-            sendGiftMessage(text)
-            playGiftAnimation(emoji)
+        GiftSheet.show(this, myNickname, list) { text, emoji, svgaUrl ->
+            sendGiftMessage(text, svgaUrl)
+            if (emoji.isNotBlank()) playGiftAnimation(emoji)
         }
     }
 
@@ -449,14 +453,15 @@ class RoomActivity : AppCompatActivity() {
         }.start()
     }
 
-    private fun sendGiftMessage(text: String) {
+    private fun sendGiftMessage(text: String, svgaUrl: String? = null) {
         val uid = auth.currentUser?.uid ?: return
-        val msg = hashMapOf(
+        val msg = hashMapOf<String, Any>(
             "senderUid"  to uid,
             "senderName" to "🎁 GIFT",
             "text"       to text,
             "timestamp"  to System.currentTimeMillis()
         )
+        if (!svgaUrl.isNullOrEmpty()) msg["svgaUrl"] = svgaUrl
         roomId?.let { id ->
             db.collection("rooms").document(id).collection("messages").add(msg)
         }
@@ -537,6 +542,44 @@ class RoomActivity : AppCompatActivity() {
         }
     }
 
+    private var messagesLoaded = false
+
+    /** Putar animasi SVGA (gift / mobil masuk) dari pesan baru milik orang lain. */
+    private fun playIncomingSvga(snapshot: QuerySnapshot) {
+        val firstLoad = !messagesLoaded
+        messagesLoaded = true
+        if (firstLoad) return
+        val me = auth.currentUser?.uid
+        val now = System.currentTimeMillis()
+        for (change in snapshot.documentChanges) {
+            if (change.type != DocumentChange.Type.ADDED) continue
+            val doc = change.document
+            val url = doc.getString("svgaUrl") ?: continue
+            if (doc.getString("senderUid") == me) continue
+            if (now - (doc.getLong("timestamp") ?: 0L) > 15_000L) continue
+            SvgaOverlay.show(this, url)
+        }
+    }
+
+    /** Kalau punya mobil terpasang: putar animasinya & umumkan ke semua orang di room. */
+    private fun announceCarEntrance(userDoc: DocumentSnapshot) {
+        val url = userDoc.getString("equippedCarUrl") ?: ""
+        if (url.isEmpty()) return
+        val uid = auth.currentUser?.uid ?: return
+        val carName = userDoc.getString("equippedCarName") ?: "kendaraan"
+        SvgaOverlay.show(this, url)
+        val msg = hashMapOf<String, Any>(
+            "senderUid"  to uid,
+            "senderName" to "🚗 MASUK",
+            "text"       to "$myNickname masuk dengan $carName",
+            "timestamp"  to System.currentTimeMillis(),
+            "svgaUrl"    to url
+        )
+        roomId?.let { id ->
+            db.collection("rooms").document(id).collection("messages").add(msg)
+        }
+    }
+
     private fun listenMessages() {
         roomId?.let { id ->
             db.collection("rooms").document(id)
@@ -545,6 +588,7 @@ class RoomActivity : AppCompatActivity() {
                 .limitToLast(100)
                 .addSnapshotListener { snapshot, _ ->
                     if (snapshot == null) return@addSnapshotListener
+                    playIncomingSvga(snapshot)
                     val messages = snapshot.documents.mapNotNull { doc ->
                         doc.data?.let { RoomMessage.fromDoc(doc.id, it) }
                     }
diff --git a/app/src/main/java/com/hayu/app/SvgaCatalog.kt b/app/src/main/java/com/hayu/app/SvgaCatalog.kt
new file mode 100644
index 0000000..989400d
--- /dev/null
+++ b/app/src/main/java/com/hayu/app/SvgaCatalog.kt
@@ -0,0 +1,60 @@
+package com.hayu.app
+
+import com.google.firebase.firestore.FirebaseFirestore
+import com.google.firebase.firestore.Query
+
+/** Katalog aset SVGA yang diunggah Developer (Firestore: koleksi svgaAssets). */
+object SvgaCatalog {
+    const val COLLECTION = "svgaAssets"
+
+    const val GIFT = "gift"
+    const val FRAME = "frame"
+    const val CAR = "car"
+    const val OTHER = "other"
+
+    /** Tambah jenis baru cukup di sini. */
+    val types = listOf(
+        GIFT to "🎁 Gift",
+        FRAME to "🖼️ Frame",
+        CAR to "🚗 Car",
+        OTHER to "✨ Lainnya"
+    )
+
+    fun typeLabel(type: String): String =
+        types.firstOrNull { it.first == type }?.second ?: type
+
+    class Asset(
+        val id: String,
+        val type: String,
+        val name: String,
+        val price: Int,
+        val url: String,
+        val emoji: String,
+        val storagePath: String,
+        val createdAt: Long
+    )
+
+    /** type = null → semua jenis. Gagal memuat → daftar kosong. */
+    fun load(type: String?, onDone: (List<Asset>) -> Unit) {
+        val col = FirebaseFirestore.getInstance().collection(COLLECTION)
+        val query: Query = if (type == null) col else col.whereEqualTo("type", type)
+        query.get()
+            .addOnSuccessListener { snap ->
+                val list = snap.documents.mapNotNull { d ->
+                    val url = d.getString("url") ?: return@mapNotNull null
+                    Asset(
+                        id = d.id,
+                        type = d.getString("type") ?: OTHER,
+                        name = d.getString("name") ?: "Tanpa nama",
+                        price = (d.getLong("price") ?: 0L).toInt(),
+                        url = url,
+                        emoji = d.getString("emoji") ?: "",
+                        storagePath = d.getString("storagePath") ?: "",
+                        createdAt = d.getLong("createdAt") ?: 0L
+                    )
+                }.sortedByDescending { it.createdAt }
+                onDone(list)
+            }
+            .addOnFailureListener { onDone(emptyList()) }
+    }
+}
diff --git a/app/src/main/java/com/hayu/app/SvgaManagerActivity.kt b/app/src/main/java/com/hayu/app/SvgaManagerActivity.kt
new file mode 100644
index 0000000..b45afee
--- /dev/null
+++ b/app/src/main/java/com/hayu/app/SvgaManagerActivity.kt
@@ -0,0 +1,395 @@
+package com.hayu.app
+
+import android.graphics.Color
+import android.graphics.drawable.GradientDrawable
+import android.net.Uri
+import android.os.Bundle
+import android.provider.OpenableColumns
+import android.text.InputType
+import android.view.Gravity
+import android.view.ViewGroup
+import android.widget.EditText
+import android.widget.LinearLayout
+import android.widget.ProgressBar
+import android.widget.ScrollView
+import android.widget.TextView
+import android.widget.Toast
+import androidx.activity.result.contract.ActivityResultContracts
+import androidx.appcompat.app.AlertDialog
+import androidx.appcompat.app.AppCompatActivity
+import com.google.firebase.auth.FirebaseAuth
+import com.google.firebase.firestore.FirebaseFirestore
+import com.google.firebase.storage.FirebaseStorage
+import com.google.firebase.storage.StorageMetadata
+import com.opensource.svgaplayer.SVGAImageView
+import com.opensource.svgaplayer.SVGAParser
+import com.opensource.svgaplayer.SVGAVideoEntity
+import java.io.File
+import java.io.FileInputStream
+
+/** Khusus Developer: upload file .svga (frame, car, gift, dll), pratinjau, hapus. */
+class SvgaManagerActivity : AppCompatActivity() {
+
+    private companion object {
+        const val MAX_BYTES = 8L * 1024 * 1024
+        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
+        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
+    }
+
+    private val db = FirebaseFirestore.getInstance()
+    private val auth = FirebaseAuth.getInstance()
+
+    private var selectedType = SvgaCatalog.GIFT
+    private var pickedFile: File? = null
+    private var uploading = false
+
+    private lateinit var etName: EditText
+    private lateinit var etPrice: EditText
+    private lateinit var etEmoji: EditText
+    private lateinit var tvFile: TextView
+    private lateinit var preview: SVGAImageView
+    private lateinit var progress: ProgressBar
+    private lateinit var btnUpload: TextView
+    private lateinit var listBox: LinearLayout
+    private val typeChips = ArrayList<Pair<TextView, String>>()
+
+    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
+        if (uri != null) onPicked(uri)
+    }
+
+    override fun onCreate(savedInstanceState: Bundle?) {
+        super.onCreate(savedInstanceState)
+        val uid = auth.currentUser?.uid ?: run { finish(); return }
+        db.collection("users").document(uid).get()
+            .addOnSuccessListener { doc ->
+                if (Role.DEVELOPER !in Role.rolesOf(doc)) {
+                    toast("Hanya untuk Developer")
+                    finish()
+                    return@addOnSuccessListener
+                }
+                buildUi()
+                loadList()
+            }
+            .addOnFailureListener { finish() }
+    }
+
+    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
+
+    private fun d(v: Int) = Ui.dp(this, v)
+
+    private fun field(hintText: String, inputKind: Int): EditText {
+        val et = EditText(this)
+        et.hint = hintText
+        et.inputType = inputKind
+        et.setTextColor(Color.WHITE)
+        et.setHintTextColor(Color.parseColor("#6B7280"))
+        et.textSize = 14f
+        val bg = GradientDrawable()
+        bg.setColor(Color.parseColor("#12122A"))
+        bg.cornerRadius = d(10).toFloat()
+        bg.setStroke(d(1), Color.parseColor("#2E2E50"))
+        et.background = bg
+        et.setPadding(d(12), d(10), d(12), d(10))
+        return et
+    }
+
+    private fun buildUi() {
+        val root = LinearLayout(this)
+        root.orientation = LinearLayout.VERTICAL
+        root.setBackgroundColor(Color.parseColor("#080818"))
+
+        val header = LinearLayout(this)
+        header.orientation = LinearLayout.HORIZONTAL
+        header.gravity = Gravity.CENTER_VERTICAL
+        header.setBackgroundColor(Color.parseColor("#0D0D3D"))
+        header.setPadding(d(16), d(14), d(16), d(14))
+        val back = TextView(this)
+        back.text = "‹"
+        back.textSize = 28f
+        back.setTextColor(Color.WHITE)
+        back.setOnClickListener { finish() }
+        header.addView(back)
+        header.addView(
+            Ui.text(this, "  SVGA Manager", 18f, Color.WHITE, true),
+            LinearLayout.LayoutParams(0, WRAP, 1f)
+        )
+        root.addView(header)
+
+        val scroll = ScrollView(this)
+        val col = LinearLayout(this)
+        col.orientation = LinearLayout.VERTICAL
+        col.setPadding(d(14), d(14), d(14), d(60))
+        scroll.addView(col)
+        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
+
+        // ---------- form upload ----------
+        val form = Ui.card(this)
+        form.addView(Ui.text(this, "⬆️ Upload SVGA baru", 16f, Ui.WHITE_SOFT, true))
+
+        form.addView(Ui.text(this, "Jenis", 12f, Ui.GRAY).also { it.setPadding(0, d(10), 0, d(4)) })
+        val chipRow = LinearLayout(this)
+        chipRow.orientation = LinearLayout.HORIZONTAL
+        for ((type, label) in SvgaCatalog.types) {
+            val chip = Ui.text(this, label, 12f, Color.WHITE, true)
+            chip.gravity = Gravity.CENTER
+            chip.setPadding(d(6), d(8), d(6), d(8))
+            chip.setOnClickListener {
+                selectedType = type
+                refreshChips()
+            }
+            typeChips.add(chip to type)
+            chipRow.addView(
+                chip,
+                LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(d(2), 0, d(2), 0) }
+            )
+        }
+        form.addView(chipRow)
+        refreshChips()
+
+        etName = field("Nama (mis. Mobil Sport, Bingkai Emas)", InputType.TYPE_CLASS_TEXT)
+        etPrice = field("Harga koin (0 = gratis)", InputType.TYPE_CLASS_NUMBER)
+        etEmoji = field("Emoji ikon (opsional)", InputType.TYPE_CLASS_TEXT)
+        val fieldLp = { LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = d(8) } }
+        form.addView(etName, fieldLp())
+        form.addView(etPrice, fieldLp())
+        form.addView(etEmoji, fieldLp())
+
+        form.addView(
+            Ui.button(this, "📂 Pilih file .svga") { picker.launch(arrayOf("*/*")) },
+            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = d(12) }
+        )
+        tvFile = Ui.text(this, "Belum ada file", 12f, Ui.GRAY)
+        tvFile.setPadding(0, d(6), 0, d(6))
+        form.addView(tvFile)
+
+        preview = SVGAImageView(this)
+        val box = GradientDrawable()
+        box.setColor(Color.parseColor("#12122A"))
+        box.cornerRadius = d(12).toFloat()
+        preview.background = box
+        form.addView(preview, LinearLayout.LayoutParams(MATCH, d(190)))
+
+        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
+        progress.max = 100
+        progress.visibility = android.view.View.GONE
+        form.addView(progress, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = d(10) })
+
+        btnUpload = Ui.button(this, "⬆️ Upload") { startUpload() }
+        form.addView(btnUpload, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = d(10) })
+        col.addView(form)
+
+        // ---------- daftar aset ----------
+        col.addView(Ui.text(this, "Aset terunggah", 16f, Ui.WHITE_SOFT, true).also {
+            it.setPadding(0, d(8), 0, d(8))
+        })
+        listBox = LinearLayout(this)
+        listBox.orientation = LinearLayout.VERTICAL
+        col.addView(listBox)
+
+        setContentView(root)
+    }
+
+    private fun refreshChips() {
+        for ((chip, type) in typeChips) {
+            chip.setBackgroundResource(
+                if (type == selectedType) R.drawable.bg_button_primary else R.drawable.bg_quick_item
+            )
+        }
+    }
+
+    // ---------- pilih & validasi file ----------
+
+    private fun onPicked(uri: Uri) {
+        var name = "file.svga"
+        var size = -1L
+        contentResolver.query(uri, null, null, null, null)?.use { c ->
+            if (c.moveToFirst()) {
+                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
+                if (n >= 0) name = c.getString(n) ?: name
+                val s = c.getColumnIndex(OpenableColumns.SIZE)
+                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
+            }
+        }
+        if (!name.lowercase().endsWith(".svga")) {
+            toast("File harus berekstensi .svga")
+            return
+        }
+        if (size > MAX_BYTES) {
+            toast("Ukuran maksimal 8 MB")
+            return
+        }
+
+        val target = File(cacheDir, "pending_upload.svga")
+        try {
+            val input = contentResolver.openInputStream(uri)
+                ?: throw IllegalStateException("Tidak bisa membaca file")
+            input.use { src -> target.outputStream().use { out -> src.copyTo(out) } }
+        } catch (e: Exception) {
+            toast("Gagal membaca file: ${e.message}")
+            return
+        }
+        if (target.length() == 0L || target.length() > MAX_BYTES) {
+            toast("Ukuran file tidak valid (maks 8 MB)")
+            return
+        }
+
+        pickedFile = null
+        tvFile.text = "⏳ Memeriksa $name ..."
+        if (etName.text.isBlank()) etName.setText(name.substring(0, name.length - 5))
+
+        // Parse lokal dulu: file rusak / bukan SVGA ditolak sebelum diunggah.
+        SVGAParser(this).decodeFromInputStream(
+            FileInputStream(target),
+            "pending_${System.currentTimeMillis()}",
+            object : SVGAParser.ParseCompletion {
+                override fun onComplete(videoItem: SVGAVideoEntity) {
+                    pickedFile = target
+                    tvFile.text = "✅ $name • ${target.length() / 1024} KB"
+                    preview.setVideoItem(videoItem)
+                    preview.loops = 0
+                    preview.startAnimation()
+                }
+
+                override fun onError() {
+                    pickedFile = null
+                    tvFile.text = "❌ $name bukan file SVGA yang valid"
+                }
+            },
+            true
+        )
+    }
+
+    // ---------- upload ----------
+
+    private fun setUploading(on: Boolean) {
+        uploading = on
+        progress.progress = 0
+        progress.visibility = if (on) android.view.View.VISIBLE else android.view.View.GONE
+        btnUpload.alpha = if (on) 0.45f else 1f
+        btnUpload.text = if (on) "Mengunggah..." else "⬆️ Upload"
+    }
+
+    private fun failMessage(prefix: String, e: Exception): String {
+        val m = e.message ?: "tidak diketahui"
+        val hint = if (m.contains("permission", true) || m.contains("not authorized", true)) {
+            "\nCek Firebase Rules (Storage & Firestore)."
+        } else ""
+        return "$prefix: $m$hint"
+    }
+
+    private fun startUpload() {
+        if (uploading) return
+        val file = pickedFile ?: run {
+            toast("Pilih file SVGA yang valid dulu")
+            return
+        }
+        val name = etName.text.toString().trim()
+        if (name.isEmpty()) {
+            toast("Isi nama aset")
+            return
+        }
+        val price = etPrice.text.toString().trim().toIntOrNull() ?: 0
+        val emoji = etEmoji.text.toString().trim()
+        val uid = auth.currentUser?.uid ?: return
+        val type = selectedType
+
+        val safe = name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifEmpty { "asset" }
+        val path = "svga/$type/${System.currentTimeMillis()}_$safe.svga"
+        val ref = FirebaseStorage.getInstance().reference.child(path)
+        val meta = StorageMetadata.Builder().setContentType("application/octet-stream").build()
+
+        setUploading(true)
+        ref.putFile(Uri.fromFile(file), meta)
+            .addOnProgressListener { s ->
+                if (s.totalByteCount > 0) {
+                    progress.progress = (100 * s.bytesTransferred / s.totalByteCount).toInt()
+                }
+            }
+            .addOnSuccessListener {
+                ref.downloadUrl
+                    .addOnSuccessListener { dl ->
+                        val data = mapOf(
+                            "type" to type,
+                            "name" to name,
+                            "price" to price.toLong(),
+                            "emoji" to emoji,
+                            "url" to dl.toString(),
+                            "storagePath" to path,
+                            "createdBy" to uid,
+                            "createdAt" to System.currentTimeMillis()
+                        )
+                        db.collection(SvgaCatalog.COLLECTION).add(data)
+                            .addOnSuccessListener {
+                                toast("Berhasil diunggah 🎉")
+                                resetForm()
+                                setUploading(false)
+                                loadList()
+                            }
+                            .addOnFailureListener { e ->
+                                toast(failMessage("Gagal menyimpan data", e))
+                                setUploading(false)
+                            }
+                    }
+                    .addOnFailureListener { e ->
+                        toast(failMessage("Gagal mengambil URL", e))
+                        setUploading(false)
+                    }
+            }
+            .addOnFailureListener { e ->
+                toast(failMessage("Upload gagal", e))
+                setUploading(false)
+            }
+    }
+
+    private fun resetForm() {
+        etName.setText("")
+        etPrice.setText("")
+        etEmoji.setText("")
+        pickedFile = null
+        tvFile.text = "Belum ada file"
+        preview.stopAnimation()
+        preview.setImageDrawable(null)
+    }
+
+    // ---------- daftar ----------
+
+    private fun loadList() {
+        SvgaCatalog.load(null) { all ->
+            listBox.removeAllViews()
+            if (all.isEmpty()) {
+                listBox.addView(Ui.text(this, "Belum ada aset.", 12f, Ui.GRAY))
+                return@load
+            }
+            for (a in all) {
+                val play = Ui.button(this, "▶") { SvgaOverlay.show(this, a.url) }
+                val del = Ui.button(this, "🗑") { confirmDelete(a) }
+                val right = LinearLayout(this)
+                right.orientation = LinearLayout.HORIZONTAL
+                right.addView(play)
+                right.addView(del, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = d(6) })
+                val priceText = if (a.price > 0) "🪙 ${a.price}" else "Gratis"
+                val desc = SvgaCatalog.typeLabel(a.type) + " • " + priceText
+                listBox.addView(Ui.row(this, a.emoji.ifBlank { "🎞️" }, a.name, desc, right))
+            }
+        }
+    }
+
+    private fun confirmDelete(a: SvgaCatalog.Asset) {
+        AlertDialog.Builder(this)
+            .setTitle("Hapus aset?")
+            .setMessage("${a.name} akan dihapus untuk semua pengguna.")
+            .setPositiveButton("Hapus") { _, _ ->
+                if (a.storagePath.isNotEmpty()) {
+                    FirebaseStorage.getInstance().reference.child(a.storagePath).delete()
+                }
+                db.collection(SvgaCatalog.COLLECTION).document(a.id).delete()
+                    .addOnSuccessListener {
+                        toast("Dihapus")
+                        loadList()
+                    }
+                    .addOnFailureListener { e -> toast(failMessage("Gagal menghapus", e)) }
+            }
+            .setNegativeButton("Batal", null)
+            .show()
+    }
+}
diff --git a/app/src/main/java/com/hayu/app/SvgaPlayer.kt b/app/src/main/java/com/hayu/app/SvgaPlayer.kt
new file mode 100644
index 0000000..1666c1f
--- /dev/null
+++ b/app/src/main/java/com/hayu/app/SvgaPlayer.kt
@@ -0,0 +1,114 @@
+package com.hayu.app
+
+import android.app.Activity
+import android.content.Context
+import android.content.ContextWrapper
+import android.view.ViewGroup
+import android.widget.ImageView
+import android.widget.RelativeLayout
+import com.opensource.svgaplayer.SVGACallback
+import com.opensource.svgaplayer.SVGAImageView
+import com.opensource.svgaplayer.SVGAParser
+import com.opensource.svgaplayer.SVGAVideoEntity
+import java.net.URL
+
+object SvgaPlayer {
+    /** loops = 1 sekali putar, 0 = berulang terus. File diunduh & di-cache oleh SVGAParser. */
+    fun play(
+        view: SVGAImageView,
+        url: String,
+        loops: Int = 1,
+        onFinish: (() -> Unit)? = null,
+        onError: (() -> Unit)? = null
+    ) {
+        try {
+            SVGAParser(view.context).decodeFromURL(URL(url), object : SVGAParser.ParseCompletion {
+                override fun onComplete(videoItem: SVGAVideoEntity) {
+                    view.setVideoItem(videoItem)
+                    view.loops = loops
+                    view.callback = object : SVGACallback {
+                        override fun onPause() {}
+                        override fun onFinished() { onFinish?.invoke() }
+                        override fun onRepeat() {}
+                        override fun onStep(frame: Int, percentage: Double) {}
+                    }
+                    view.startAnimation()
+                }
+
+                override fun onError() {
+                    onError?.invoke()
+                }
+            })
+        } catch (e: Exception) {
+            onError?.invoke()
+        }
+    }
+}
+
+/** Animasi layar penuh sekali putar (gift, mobil masuk room). Tidak menghalangi sentuhan. */
+object SvgaOverlay {
+    private const val TAG = "hayu_svga_overlay"
+
+    fun show(context: Context, url: String) {
+        val activity = context.findActivity() ?: return
+        if (activity.isFinishing || activity.isDestroyed) return
+        val root = activity.window.decorView as? ViewGroup ?: return
+
+        for (i in root.childCount - 1 downTo 0) {
+            if (root.getChildAt(i).tag == TAG) root.removeViewAt(i)
+        }
+
+        val view = SVGAImageView(activity)
+        view.tag = TAG
+        view.scaleType = ImageView.ScaleType.FIT_CENTER
+        root.addView(
+            view,
+            ViewGroup.LayoutParams(
+                ViewGroup.LayoutParams.MATCH_PARENT,
+                ViewGroup.LayoutParams.MATCH_PARENT
+            )
+        )
+
+        val remove = { view.post { (view.parent as? ViewGroup)?.removeView(view) }; Unit }
+        SvgaPlayer.play(view, url, 1, onFinish = remove, onError = remove)
+        view.postDelayed({ remove() }, 20_000L) // pengaman kalau animasi macet
+    }
+
+    private fun Context.findActivity(): Activity? {
+        var current: Context = this
+        while (current is ContextWrapper) {
+            if (current is Activity) return current
+            val next = current.baseContext
+            if (next === current) break
+            current = next
+        }
+        return current as? Activity
+    }
+}
+
+/** Bingkai SVGA di atas avatar yang berada di dalam RelativeLayout. */
+object SvgaFrame {
+    private const val TAG = "hayu_svga_frame"
+
+    fun attach(avatar: ImageView, url: String?) {
+        val parent = avatar.parent as? ViewGroup ?: return
+        for (i in parent.childCount - 1 downTo 0) {
+            if (parent.getChildAt(i).tag == TAG) parent.removeViewAt(i)
+        }
+        if (url.isNullOrEmpty()) return
+
+        val lp = avatar.layoutParams as? RelativeLayout.LayoutParams ?: return
+        if (lp.width <= 0 || lp.height <= 0) return
+        val size = (lp.width * 1.45f).toInt()
+
+        val view = SVGAImageView(avatar.context)
+        view.tag = TAG
+        view.scaleType = ImageView.ScaleType.FIT_CENTER
+        val frameLp = RelativeLayout.LayoutParams(size, size)
+        frameLp.addRule(RelativeLayout.CENTER_HORIZONTAL)
+        frameLp.topMargin = lp.topMargin - (size - lp.height) / 2
+        parent.addView(view, frameLp)
+
+        SvgaPlayer.play(view, url, 0)
+    }
+}
diff --git a/app/src/main/java/com/hayu/app/TokoActivity.kt b/app/src/main/java/com/hayu/app/TokoActivity.kt
index 2c8487b..2abe6d0 100644
--- a/app/src/main/java/com/hayu/app/TokoActivity.kt
+++ b/app/src/main/java/com/hayu/app/TokoActivity.kt
@@ -1,5 +1,7 @@
 package com.hayu.app
 
+import android.view.ViewGroup
+import android.widget.LinearLayout
 import com.google.firebase.firestore.DocumentSnapshot
 
 class TokoActivity : SimplePageActivity() {
@@ -39,6 +41,90 @@ class TokoActivity : SimplePageActivity() {
             val desc = if (item.id in owned) "Sudah dimiliki" else "Gelar • ${item.price} koin"
             container.addView(Ui.row(this, item.emoji, item.name, desc, btn))
         }
+
+        renderSvgaShop(user, owned)
+    }
+
+    // Bingkai avatar & kendaraan masuk room (SVGA unggahan Developer)
+    private fun renderSvgaShop(user: DocumentSnapshot, owned: Set<String>) {
+        val coins = (user.getLong("coins") ?: 0L).toInt()
+        val box = LinearLayout(this)
+        box.orientation = LinearLayout.VERTICAL
+        container.addView(box)
+
+        val sections = listOf(
+            Triple(SvgaCatalog.FRAME, "🖼️ Bingkai Avatar", "equippedFrame"),
+            Triple(SvgaCatalog.CAR, "🚗 Kendaraan Masuk Room", "equippedCar")
+        )
+        SvgaCatalog.load(null) { all ->
+            for ((type, title, field) in sections) {
+                val list = all.filter { it.type == type }
+                if (list.isEmpty()) continue
+                val equippedUrl = user.getString("${field}Url") ?: ""
+                val head = Ui.text(this, title, 15f, Ui.WHITE_SOFT, true)
+                head.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 6))
+                box.addView(head)
+
+                for (a in list) {
+                    val have = a.price == 0 || "svga_${a.id}" in owned
+                    val main = when {
+                        equippedUrl == a.url -> Ui.button(this, "Lepas") { equipSvga(field, "", "") }
+                        have -> Ui.button(this, "Pakai") { equipSvga(field, a.url, a.name) }
+                        else -> Ui.button(this, "🪙 ${a.price}", coins >= a.price) { buySvga(a) }
+                    }
+                    val preview = Ui.button(this, "▶") { SvgaOverlay.show(this, a.url) }
+                    val right = LinearLayout(this)
+                    right.orientation = LinearLayout.HORIZONTAL
+                    right.addView(preview)
+                    val lp = LinearLayout.LayoutParams(
+                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
+                    )
+                    lp.marginStart = Ui.dp(this, 6)
+                    right.addView(main, lp)
+
+                    val desc = when {
+                        equippedUrl == a.url -> "Sedang dipakai"
+                        have -> "Sudah dimiliki"
+                        else -> "${a.price} koin"
+                    }
+                    val icon = a.emoji.ifBlank { if (type == SvgaCatalog.FRAME) "🖼️" else "🚗" }
+                    box.addView(Ui.row(this, icon, a.name, desc, right))
+                }
+            }
+        }
+    }
+
+    private fun equipSvga(field: String, url: String, name: String) {
+        val uid = auth.currentUser?.uid ?: return
+        db.collection("users").document(uid)
+            .update(mapOf("${field}Url" to url, "${field}Name" to name))
+            .addOnSuccessListener { reload() }
+            .addOnFailureListener { toast("Gagal: ${it.message}") }
+    }
+
+    private fun buySvga(a: SvgaCatalog.Asset) {
+        val uid = auth.currentUser?.uid ?: return
+        val ref = db.collection("users").document(uid)
+        val itemId = "svga_${a.id}"
+        db.runTransaction { tx ->
+            val snap = tx.get(ref)
+            val owned = (snap.get("ownedItems") as? List<*>)?.map { o -> o.toString() } ?: emptyList()
+            val coins = snap.getLong("coins") ?: 0L
+            if (itemId in owned) throw IllegalStateException("Sudah dimiliki")
+            if (coins < a.price) throw IllegalStateException("Koin tidak cukup")
+            tx.update(
+                ref, mapOf(
+                    "coins" to (coins - a.price),
+                    "ownedItems" to (owned + itemId)
+                )
+            )
+            null
+        }.addOnSuccessListener {
+            toast("Berhasil membeli ${a.name} 🎉")
+            reload()
+        }.addOnFailureListener {
+            toast("Gagal: ${it.message}")
+        }
     }
 
     private fun equip(title: String) {
diff --git a/settings.gradle.kts b/settings.gradle.kts
index bd6032d..53c1165 100644
--- a/settings.gradle.kts
+++ b/settings.gradle.kts
@@ -10,6 +10,7 @@ dependencyResolutionManagement {
     repositories {
         google()
         mavenCentral()
+        maven { url = uri("https://jitpack.io") }
     }
 }
 
PATCH_EOF

echo "▶ Mengecek patch..."
if git apply --check "$P" 2>/dev/null; then
  git apply "$P"
  echo "▶ Terpasang (cocok persis)."
elif patch -p1 --dry-run -F3 < "$P" >/dev/null 2>&1; then
  patch -p1 -F3 < "$P"
  echo "▶ Terpasang (dengan penyesuaian baris kecil, cek hasilnya)."
else
  echo "❌ Patch tidak cocok dengan repo-mu (file-file ini sudah berubah dari versi saya)."
  echo "   Tidak ada yang diubah. Kirim zip repo terbaru ke Claude untuk disesuaikan."
  rm -f "$P"
  exit 1
fi
rm -f "$P"

echo ""
echo "✅ Selesai: SVGA Manager terpasang."
echo "   Lanjut: git add -A && git commit -m \"SVGA manager\" && git push"
echo "   Catatan: aktifkan Firebase Storage & atur Rules (tulis hanya developer)."
